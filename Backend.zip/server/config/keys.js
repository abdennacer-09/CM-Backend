
module.exports = {
    mongoURI: "mongodb://localhost/CabinetMedical",
    secret: 'yoursecret'
};