
/*const mongoose = require('mongoose');
const Schema = mongoose.Schema;
//const {patientSchema} = require('../models/patient');

const secpatSchema = mongoose.Schema({


    patient:[{
        type : Schema.Types.ObjectId,
        ref : 'Patient'
    }],
    
    secretaire:[{
        type: Schema.Types.ObjectId,
        ref: 'secretaire'
    }] 
    
});

module.exports = mongoose.model('SecPat', secpatSchema);*/